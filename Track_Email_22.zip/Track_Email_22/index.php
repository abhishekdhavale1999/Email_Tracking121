<?php
$connect = new PDO("mysql:host=localhost;dbname=testing", "root", "");
$base_url = 'http://localhost/track_email_22/'; 
$message = '';
if(isset($_POST["send"]))
{
    require_once 'vendor/autoload.php';
    $mail = new PHPMailer\PHPMailer\PHPMailer;
    $mail->IsSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->Port = '587';
    $mail->SMTPAuth = true;
    $mail->Username = 'abhishekdhavale1999@gmail.com';
    $mail->Password = 'hvuc qdhq ygcp ctbk';
    $mail->SMTPSecure = 'tls';
    $mail->From = 'abhishekdhavale1999@gmail.com';
    $mail->FromName = 'Abhi';
    $mail->WordWrap = 50;
    $mail->IsHTML(true);
    $mail->Subject = $_POST['email_subject'];
    $track_code = md5(rand());
    $message_body = $_POST['email_body'];
    
    if (!empty($_POST['receiver_email'])) {
        $receivers = explode(',', $_POST['receiver_email']);
        foreach ($receivers as $receiver) {
            $receiver = trim($receiver);
            if (!empty($receiver) && filter_var($receiver, FILTER_VALIDATE_EMAIL)) {
                $mail->ClearAddresses();
                $mail->AddAddress($receiver);

                $individual_message_body = $message_body . '<img src="'.$base_url.'email_track.php?code='.$track_code.'" width="1" height="1" />';
                
                $mail->Body = $individual_message_body;

                if($mail->Send())
                {
                    $data = array(
                        ':email_subject'   =>  $_POST["email_subject"],
                        ':email_body'    =>  $_POST["email_body"],
                        ':email_address'   =>  $receiver,
                        ':email_track_code'   =>  $track_code
                    );
                    $query = "
                    INSERT INTO email_data 
                    (email_subject, email_body, email_address, email_track_code) VALUES 
                    (:email_subject, :email_body, :email_address, :email_track_code)
                    ";

                    $statement = $connect->prepare($query);
                    if($statement->execute($data))
                    {
                        $message .= '<label class="text-success"> Email Send to ' . $receiver . '</label><br>';
                    }
                }
                else
                {
                    $message .= '<label class="text-danger">Failed to send email to ' . $receiver . '</label><br>';
                }
            }
        }
    } elseif (!empty($_FILES['file']['tmp_name'])) {
       
        $file = $_FILES['file']['tmp_name'];
        $handle = fopen($file, "r");
        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            $receiver = $data[0]; 
            if (!empty($receiver) && filter_var($receiver, FILTER_VALIDATE_EMAIL)) {
                
                $mail->ClearAddresses();
                $mail->AddAddress($receiver);

                $individual_message_body = $message_body . '<img src="'.$base_url.'email_track.php?code='.$track_code.'" width="1" height="1" />';
                
                $mail->Body = $individual_message_body;
                if($mail->Send())
                {
                    $data = array(
                        ':email_subject'   =>  $_POST["email_subject"],
                        ':email_body'    =>  $_POST["email_body"],
                        ':email_address'   =>$receiver,
                        ':email_track_code'   =>$track_code
                    );
                    $query = "
                    INSERT INTO email_data 
                    (email_subject, email_body, email_address, email_track_code) VALUES 
                    (:email_subject, :email_body, :email_address, :email_track_code)
                    ";
                    $statement = $connect->prepare($query);
                    if($statement->execute($data))
                    {
                        $message .= '<label class="text-success">Email Sent Successfully to ' . $receiver . '</label><br>';
                    }
                }
                else
                {
                    $message .= '<label class="text-danger">Failed to send email to ' . $receiver . '</label><br>';
                }
            }
        }
        fclose($handle);
    }
}
function fetch_email_track_data($connect)
{
    $query = "SELECT * FROM email_data ORDER BY email_id";
    $statement = $connect->prepare($query);
    $statement->execute();
    $result = $statement->fetchAll();
    $total_row = $statement->rowCount();
    $output = '
    <div class="table-responsive">
        <table class="table table-bordered table-striped">
		<thead class="thead-dark">
		<tr>
		<th style="width: 15%;" class="text-center">Email</th>
		<th style="width: 25%;" class="text-center">Subject</th>
		<th style="width: 10%;" class="text-center">Status</th>
		<th style="width: 20%;" class="text-center">Open Datetime</th>
		<th style="width: 30%;" class="text-center">Email Open Count</th>
		</tr>
	</thead>
    ';
    if($total_row > 0)
    {
        foreach($result as $row)
        {
            $status = '';
            if($row['email_status'] == 'yes')
            {
                $status = '<span class="label label-success">Open</span>';
            }
            else
            {
                $status = '<span class="label label-danger">Not Open</span>';
            }
            $output .= '
                <tr>
                    <td>'.$row["email_address"].'</td>
                    <td>'.$row["email_subject"].'</td>
                    <td>'.$status.'</td>
                    <td>'.$row["email_open_datetime"].'</td>
					<td>'.$row["email_open_count"].'</td>
                </tr>
            ';
        }
    }
    else
    {
        $output .= '
        <tr>
            <td colspan="4" align="center">No Email Send Data Found</td>
        </tr>
        ';
    }
    $output .= '</table></div>';
    return $output;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Intent Amplify Email Marketing</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            color: #333;
            font-family: Arial, sans-serif;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 30px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .mt-5 {
            margin-top: 50px;
        }
        .mb-4 {
            margin-bottom: 30px;
        }
        .mb-5 {
            margin-bottom: 50px;
        }
        .btn-info {
            background-color: #17a2b8;
            border-color: #17a2b8;
        }
        .btn-info:hover {
            background-color: #138496;
            border-color: #117a8b;
        }
        .table thead th {
            background-color: #007bff;
            color: #fff;
            border-color: #007bff;
        }
        .table th,
        .table td {
            vertical-align: middle;
        }
        .table-responsive {
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            font-weight: bold;
        }
        textarea {
            resize: vertical;
        }
        .tracking-section {
            margin-top: 50px;
        }
        .tracking-table {
            margin-top: 20px;
        }
        .label-success {
            background-color: #28a745;
            color: #fff;
            padding: 5px 10px;
            border-radius: 5px;
        }
        .label-danger {
            background-color: #dc3545;
            color: #fff;
            padding: 5px 10px;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h3 class="text-center mb-4">Intent Amplify Email Marketing</h3>
        <?php echo $message; ?>
        <form method="post" enctype="multipart/form-data" class="mb-5">
            <div class="form-group">
                <label for="email_subject">Email Subject</label>
                <input type="text" name="email_subject" class="form-control" required />
            </div>
            <div class="form-group">
                <label for="receiver_email">Enter Receiver Email (separated by commas)</label>
                <input type="text" name="receiver_email" class="form-control" />
            </div>
            <div class="form-group">
                <label for="file">Upload CSV File with Receiver Emails</label>
                <input type="file" name="file" class="form-control-file" />
            </div>
            <div class="form-group">
                <label for="email_body">Email Body</label>
                <textarea name="email_body" rows="5" class="form-control" required></textarea>
            </div>
            <button type="submit" name="send" class="btn btn-info btn-block">Send Email</button>
        </form>
        
        
<div class="text-center mb-4">
    <button type="button" class="btn btn-info" id="showTracking">Show Tracking Results</button>
</div>


<div id="trackingSection" style="display: none;">
    <?php echo fetch_email_track_data($connect); ?>
</div>

<script>

    document.getElementById('showTracking').addEventListener('click', function() {
        var trackingSection = document.getElementById('trackingSection');
        if (trackingSection.style.display === 'none') {
            trackingSection.style.display = 'block';
        } else {
            trackingSection.style.display = 'none';
        }
    });
</script>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

