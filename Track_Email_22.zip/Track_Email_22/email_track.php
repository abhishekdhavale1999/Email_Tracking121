<?php

$connect = new PDO("mysql:host=localhost;dbname=testing", "root","");

if(isset($_GET["code"]))
{
    $query = "
        UPDATE email_data 
        SET email_status = 'yes', email_open_datetime = :open_datetime
        WHERE email_track_code = :code
        AND email_status = 'no'
    ";
    $statement = $connect->prepare($query);
    $statement->bindParam(':open_datetime', date("Y-m-d H:i:s"));
    $statement->bindParam(':code', $_GET["code"]);
    $statement->execute();

  
    $queryCount = "
        UPDATE email_data 
        SET email_open_count = email_open_count + 1
        WHERE email_track_code = :code
    ";
    $statementCount = $connect->prepare($queryCount);
    $statementCount->bindParam(':code', $_GET["code"]);
    $statementCount->execute();
}
header("Content-type: image/png");
readfile("pixel.png"); 
exit;

?>
