<?php

$connect = new PDO("mysql:host=localhost;dbname=testing", "root", "");

if (isset($_GET["code"])) {
    
    $imageLoadTime = date("Y-m-d H:i:s");
    $query = "
        UPDATE email_data 
        SET email_status = 'yes', 
            email_open_datetime = :open_datetime,
            email_image_load_datetime = :image_load_datetime
        WHERE email_track_code = :code
        AND email_status = 'no'
    ";
    $statement = $connect->prepare($query);
    $statement->bindParam(':open_datetime', $imageLoadTime);
    $statement->bindParam(':image_load_datetime', $imageLoadTime);
    $statement->bindParam(':code', $_GET["code"]);
    $statement->execute();

    header("Content-type: image/png");
    readfile("pixel.png");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Tracking Pixel</title>
    <script>
        window.addEventListener('unload', function () {
            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'track_time_spent.php', false); 
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.send('code=<?php echo isset($_GET["code"]) ? $_GET["code"] : '' ?>');
        });
    </script>
</head>
<body>
    <img src="pixel.png" alt="Pixel" style="display: none;">
</body>
</html>
