<?php

$connect = new PDO("mysql:host=localhost;dbname=testing", "root", "");

$query = "SELECT * FROM email_data ORDER BY email_id";
$statement = $connect->prepare($query);
$statement->execute();
$result = $statement->fetchAll();

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=email_tracking_data.csv');

$output = fopen('php://output', 'w');

fputcsv($output, array('campaign_name','Email', 'Subject', 'Status', 'Open Datetime', 'Email Open Count', 'Time Spent',));

foreach ($result as $row) {
    $status = ($row['email_status'] == 'yes') ? 'Open' : 'Not Open';
    fputcsv($output, array($row['campaign_name'], $row['email_address'], $row['email_subject'], $status, $row['email_open_datetime'], $row['email_open_count'], $row['time_spent']));
}
fclose($output);
?>
