<?php
$connect = new PDO("mysql:host=localhost;dbname=testing", "root", "");
$base_url = 'http://localhost/track_email_22/';
$message = '';

if(isset($_POST["send"])) {
    require_once 'vendor/autoload.php';
    $mail = new PHPMailer\PHPMailer\PHPMailer;
    $mail->IsSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->Port = '587';
    $mail->SMTPAuth = true;
    $mail->Username = 'abhishekdhavale1999@gmail.com';
    $mail->Password = 'bpqr cpet uhyv nwof';
    $mail->SMTPSecure = 'tls';
    $mail->From = 'abhishekdhavale1999@gmail.com';
    $mail->FromName = 'Abhi';
    $mail->WordWrap = 100;
    $mail->IsHTML(true);
    $mail->Subject = $_POST['email_subject'];
    
    $message_body = $_POST['email_body'];
    
    if (!empty($_POST['receiver_email'])) {
        $receivers = explode(',', $_POST['receiver_email']);
        foreach ($receivers as $receiver) {
            $receiver = trim($receiver);
            if (!empty($receiver) && filter_var($receiver, FILTER_VALIDATE_EMAIL)) {
                $track_code = generateUniqueTrackCode($connect);
                $mail->ClearAddresses();
                $mail->AddAddress($receiver);

                $individual_message_body = $message_body . '<img src="'.$base_url.'email_track.php?code='.$track_code.'" width="1" height="1" />';
                
                $mail->Body = $individual_message_body;

                if($mail->Send()) {
                    $data = array(
                        ':campaign_name'   =>  $_POST["campaign_name"],
                        ':email_subject'   =>  $_POST["email_subject"],
                        ':email_body'    =>  $_POST["email_body"],
                        ':email_address'   =>  $receiver,
                        ':email_track_code'   =>  $track_code
                    );
                    $query = "
                    INSERT INTO email_data 
                    (campaign_name, email_subject, email_body, email_address, email_track_code) VALUES 
                    (:campaign_name, :email_subject, :email_body, :email_address, :email_track_code)
                    ";

                    $statement = $connect->prepare($query);
                    if($statement->execute($data)) {
                        $message .= '<label class="text-success"> Email Sent to ' . $receiver . '</label><br>';
                    }
                } else {
                    $message .= '<label class="text-danger">Failed to send email to ' . $receiver . '</label><br>';
                }
            }
        }
    } elseif (!empty($_FILES['file']['tmp_name'])) {
        $file = $_FILES['file']['tmp_name'];
        $handle = fopen($file, "r");
        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            $receiver = $data[0]; 
            if (!empty($receiver) && filter_var($receiver, FILTER_VALIDATE_EMAIL)) {
                $track_code = generateUniqueTrackCode($connect);
                
                $mail->ClearAddresses();
                $mail->AddAddress($receiver);

                $individual_message_body = $message_body . '<img src="'.$base_url.'email_track.php?code='.$track_code.'" width="1" height="1" />';
                
                $mail->Body = $individual_message_body;
                if($mail->Send()) {
                    $data = array(
                        ':campaign_name'   =>  $_POST["campaign_name"],
                        ':email_subject'   =>  $_POST["email_subject"],
                        ':email_body'    =>  $_POST["email_body"],
                        ':email_address'   =>$receiver,
                        ':email_track_code'   =>$track_code
                    );
                    $query = "
                    INSERT INTO email_data 
                    (campaign_name, email_subject, email_body, email_address, email_track_code) VALUES 
                    (:campaign_name, :email_subject, :email_body, :email_address, :email_track_code)
                    ";
                    $statement = $connect->prepare($query);
                    if($statement->execute($data)) {
                        $message .= '<label class="text-success">Email Sent to ' . $receiver . '</label><br>';
                    }
                } else {
                    $message .= '<label class="text-danger">Failed to send email to ' . $receiver . '</label><br>';
                }
            }
        }
        fclose($handle);
    }
}
function generateUniqueTrackCode($connect) {
    $track_code = md5(rand());
    while(true) {
        $check_query = "SELECT COUNT(*) FROM email_data WHERE email_track_code = :email_track_code";
        $check_statement = $connect->prepare($check_query);
        $check_statement->bindParam(':email_track_code', $track_code);
        $check_statement->execute();
        $count = $check_statement->fetchColumn();

        if($count == 0) {
            break;
        } else {
            $track_code = md5(rand());
        }
    }
    return $track_code;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IA Email Marketing</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            color: #333;
            font-family: Arial, sans-serif;
        }

        .container {
            max-width: 1300px;
            margin: 50px auto;
            padding: 30px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

        .logo-container {
            text-align: center;
            margin-bottom: 20px;
        }

        .logo-container img {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            box-shadow: white;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
        }

        textarea {
            resize: vertical;
        }

        .btn-info {
            background-color: #17a2b8;
            border-color: #17a2b8;
            transition: background-color 0.3s ease;
        }

        .btn-info:hover {
            background-color: #138496;
            border-color: #117a8b;
        }

        .preview-container {
            border: 1px solid #ccc;
            padding: 10px;
            margin-top: 20px;
        }

        .preview-box {
            max-height: 200px;
            overflow: auto;
        }

        .preview-large {
            max-height: 600px;
            overflow: auto;
        }

        .loading-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 1);
            z-index: 9999;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .page-container {
            border: 2px solid black; 
            border-radius: 20px;
            padding: 40px;
            margin: 30px auto; 
            max-width: 1000px;
        }

        .rotating-logo {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            animation: rotateLogo 2s linear infinite;
        }

        @media (max-width: 576px) {
            .container {
                padding: 15px;
            }
        }
    </style>
</head>
<body>
<div class="page-container">
    <div class="container">
        <div class="logo-container">
            <img src="http://localhost/track_email_22/IA1.jpg" alt="Logo">
        </div>
        
        <form id="emailForm" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="campaign_name">Campaign Name</label>
                <input type="text" name="campaign_name" class="form-control" required placeholder="Enter Campaign Name">
            </div>
            <div class="form-group">
                <label for="email_subject">Email Subject</label>
                <input type="text" name="email_subject" class="form-control" required placeholder="Email Subject">
            </div>
            <div class="form-group">
                <label for="receiver_email">Enter Receiver Email</label>
                <input type="text" name="receiver_email" class="form-control" placeholder="Enter Receiver Email">
            </div>
            <div class="form-group">
                <label for="file">Upload CSV File with Receiver Emails</label>
                <input type="file" name="file" class="form-control-file" placeholder="Upload CSV File">
            </div>
            <div class="form-group">
                <label for="email_body">Email Body</label>
                <textarea name="email_body" id="email_body" rows="5" class="form-control" required placeholder="Email Body" oninput="updatePreview()"></textarea>
            </div>
            <div class="preview-container" align="center">
                <strong>POC Preview:</strong><br>
                <div id="previewContent" class="preview-box" onclick="togglePreviewSize()"></div>
            </div>
            <button type="submit" name="send" class="btn btn-info btn-block">Send Email</button>
        </form>
    </div>

    <div class="loading-overlay">
        <div class="logo-container">
            <img src="http://localhost/track_email_22/PA" alt="Logo" class="rotating-logo">
        </div>
    </div>

    <div class="container mt-4">
        <div class="text-center">
            <a href="tracking_results.php" class="btn btn-info">Track Email</a>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#email_body').on('input', function() {
                var emailBody = $(this).val();
                $('#previewContent').html(emailBody);
            });

            function togglePreviewSize() {
                var preview = $('#previewContent');
                if (preview.hasClass('preview-box')) {
                    preview.removeClass('preview-box');
                    preview.addClass('preview-large');
                } else {
                    preview.removeClass('preview-large');
                    preview.addClass('preview-box');
                }
            }

            
            $('#emailForm').submit(function() {
                
                $('.loading-overlay').show();
            });

            function hideLoadingOverlay() {
                $('.loading-overlay').hide();
            }

            function handleEmailSendingCompletion() {
                
                setTimeout(function() {
                    hideLoadingOverlay();
                }, 2000);
            }

            handleEmailSendingCompletion();
        });
    </script>
    <footer>
        <div class="container" align="center">
            <p><b>&copy; 2024 Intent-Amplify Email Marketing. All rights reserved.<b></p>
        </div>
    </footer>
</body>
</html>
