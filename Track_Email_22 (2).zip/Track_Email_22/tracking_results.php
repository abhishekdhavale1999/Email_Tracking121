<?php
$connect = new PDO("mysql:host=localhost;dbname=testing", "root", "");

function fetch_email_track_data($connect)
{
    $query = "SELECT DISTINCT campaign_name FROM email_data ORDER BY campaign_name";
    $statement = $connect->prepare($query);
    $statement->execute();
    $campaigns = $statement->fetchAll(PDO::FETCH_COLUMN);
    $output = '
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="campaign" style="font-weight: bold;">Select Campaign:</label>
                    <select id="campaign" class="form-control" onchange="filterTable()">
                        <option value="All" style="font-weight: bold;">All Campaigns</option>';
    foreach ($campaigns as $campaign) 
    {
        $output .= '<option value="' . $campaign . '">' . $campaign . '</option>';
    }
    $output .= '
                    </select>
                </div>
            </div>
        </div>
        <div class="table-responsive">
            <table id="emailData" class="table table-bordered table-striped">
                <thead class="thead-dark">
                    <tr>
                        <th>Campaign Name</th>
                        <th>Email</th>
                        <th>Subject</th>
                        <th>Status</th>
                        <th>Open Datetime</th>
                        <th>Email Open Count</th>
                        <th>Time Spent</th>     
                        <th> POC Click Time</th> 
                        
                        
                    </tr>
                </thead>
                <tbody>';
    foreach ($campaigns as $campaign) {
        $query = "SELECT * FROM email_data WHERE campaign_name = :campaign_name";
        $statement = $connect->prepare($query);
        $statement->execute(['campaign_name' => $campaign]);
        $result = $statement->fetchAll();

        foreach ($result as $row) {
            $status = ($row['email_status'] == 'yes') ? '<span class="badge badge-success">Open</span>' : '<span class="badge badge-danger">Not Open</span>';
            $output .= '
                <tr data-campaign="' . $campaign . '">
                    <td>' . $row["campaign_name"] . '</td>
                    <td>' . $row["email_address"] . '</td>
                    <td>' . $row["email_subject"] . '</td>
                    <td>' . $status . '</td>
                    <td>' . $row["email_open_datetime"] . '</td>
                    <td>' . $row["email_open_count"] . '</td>
                    <td>' . $row["time_spent"] . '</td>
                    <td>' . $row["Click_Time"] . '</td>
                    
                </tr>';
        }
    }

    if (empty($campaigns)) {
        $output .= '
            <tr>
                <td colspan="8" class="text-center">No Email Send Data Found</td>
            </tr>';
    }
    $output .= '
                </tbody>
            </table>
        </div>
    </div>';

    return $output;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Tracking Dashboard</title>
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <style>
        body {
            background-color: #f8f9fa;
            padding-top: 50px;
            text-align:center;
        }

        .container {
            padding-top: 20px;
        }

        h2 {
            margin-bottom: 20px;
        }

        .badge {
            font-size: 14px;
            padding: 6px 10px;
            border-radius: 20px;
            text-align:center;
        }

        .btn-container {
            margin-top: 20px;
        }

        .table-responsive {
            margin-top: 20px;
        }

        .btn {
            font-size: 17px;
            border-radius: 6px;
            padding: 10px;
            margin-bottom: 10px;
            text-align:center;
        }

        .btn-primary-custom {
            background-color: #007bff;
            border-color: #007bff;
            text-align:center;
        }

        .btn-custom {
            font-size: 17px;
            border-radius: 6px;
            padding: 10px;
            width: 48%;
            text-align: center;
        }

        .btn-success-custom {
            background-color: #28a745;
            border-color: #28a745;
            width: 230px;
            color: white;
            text-align: center;
        }

        .btn-danger-custom {
            background-color: #dc3545;
            border-color: #dc3545;
            width: 230px;
            color: white;
            text-align: center;
        }

        .btn-primary-custom:hover,
        .btn-success-custom:hover,
        .btn-danger-custom:hover {
            filter: brightness(80%);
        }
        .btn-back-custom,
        .btn-next-custom {
            color: white;
            background-color: #008080;
            border-color: #008080;
            width: 110px;
            height: 40px;
            text-align: center;
        }
        .table-bordered th,
        .table-bordered td {
            border: 1.5px solid black;
        }
        .rotating-logo {
            width: 160px;
            height: 160px;
            animation: rotateLogo 2s linear infinite;
        }
        .loading-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 1);
            z-index: 999;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .logo-container {
            text-align: center;
            margin-bottom: 20px;
        }
        .logo-container img {
            width: 150px;
            height: 150px;
            border-radius: 60%;
            box-shadow: white;
        }
        @media (max-width: 768px) {
            .btn-container {
                flex-direction: column;
            }

            .btn {
                width: 100%;
            }
        }
        .page-container {
            border: 2px solid black; 
            border-radius: 20px;
            padding: 40px;
            margin: 30px auto; 
            max-width: 1000px;
        }
        .container {
            max-width: 1300px;
            margin: 50px auto;
            padding: 30px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

        .table {
            width: 100%;
            border-collapse: collapse;
        }

       

        .table tbody+tbody {
            border-top: 2px solid white;
        }   

        .table-bordered {
            border: 2px solid black;
        }

        
    </style>
    <script>
        function filterTable() {
            var selectedCampaign = document.getElementById('campaign').value;
            var rows = document.querySelectorAll('#emailData tbody tr');
            rows.forEach(function(row) {
                var campaign = row.dataset.campaign;
                if (selectedCampaign === 'All' || campaign === selectedCampaign) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }
        function confirmDelete() {
            var campaign = document.getElementById('campaign').value;
            if (campaign === 'All') {
                alert('Please select a campaign to delete.');
            } else {
                var confirmation = confirm('Are you sure you want to delete this campaign?');
                if (confirmation) {
                    document.getElementById('deleteCampaign').value = campaign;
                    document.getElementById('deleteForm').submit();
                }
            }
        }
        function confirmDownload() {
            var campaign = document.getElementById('campaign').value;
            if (campaign === 'All') {
                alert('Please select a campaign to download.');
            } else {
                var confirmation = confirm('Are you sure you want to download this campaign data?');
                if (confirmation) {
                    document.getElementById('downloadCampaign').value = campaign;
                    document.getElementById('downloadForm').submit();
                }
            }
        }

        function goBack() {
            window.location.href = 'index.php';
        }
    </script>
</head>

<body>
    <div class="page-container">
        <div class="container mt-5">
            <div class="logo-container">
                <img src="http://localhost/track_email_22/IA1.jpg" >
            </div>
            <h2 class="text-center mb-4">Tracking Dashboard</h2>
            
            <?php echo fetch_email_track_data($connect); ?>
            
            <div class="btn-container">
                <div class="row justify-content-center">
                    <div class="col-md-6" align="left">
                        <form method="post" id="deleteForm" action="delete_campaign.php">
                            <input type="hidden" name="campaign" id="deleteCampaign">
                            <button type="button" class="btn btn-danger-custom btn-block" onclick="confirmDelete()">Delete Campaign</button>
                        </form>
                    </div>
                    <div class="loading-overlay">
                        <div class="logo-container">
                            <img src="http://localhost/track_email_22/PA" alt="Logo" class="rotating-logo">
                        </div>
                    </div>
                    <div class="col-md-6" align="right">
                        <form method="post" id="downloadForm" action="download_campaign.php">
                            <input type="hidden" name="download_campaign" id="downloadCampaign">
                            <button type="button" class="btn btn-success-custom btn-block" onclick="confirmDownload()">Download Campaign Data</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="container mt-4">
            <div class="row justify-content-center">
                <div class="col-md-6" align="right">
                    <a href="index.php" class="btn btn-back-custom btn-block">Back</a>
                </div>
                <div class="col-md-6" align="left">
                    <a href="dashboard.php" class="btn btn-next-custom btn-block">Next</a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#emailForm').submit(function(e) {
                $('.loading-overlay').show(); 
            });

            function hideLoadingOverlay() {
                $('.loading-overlay').hide();
            }

            function handleEmailSendingCompletion() {
                setTimeout(hideLoadingOverlay, 2000); 
            }
            handleEmailSendingCompletion();
        });
    </script>
    <footer>
        <div class="container" align="center">
            <p><b>&copy; 2024 Intent-Amplify Email Marketing. All rights reserved.<b></p>
        </div>
    </footer>
</body>
</html>

