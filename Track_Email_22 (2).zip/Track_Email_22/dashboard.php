<?php
$connect = new PDO("mysql:host=localhost;dbname=testing", "root", "");
function fetch_campaign_statistics($connect, $selected_campaign)
{
    $query = "SELECT campaign_name, 
                     SUM(CASE WHEN email_status = 'yes' THEN 1 ELSE 0 END) AS opened_emails,
                     SUM(CASE WHEN email_status = 'no' THEN 1 ELSE 0 END) AS not_opened_emails,
                     SUM(CASE WHEN email_status = 'bounce' THEN 1 ELSE 0 END) AS bounced_emails,
                     COUNT(*) AS total_emails
              FROM email_data
              WHERE campaign_name = :campaign
              GROUP BY campaign_name";
    $statement = $connect->prepare($query);
    $statement->execute(['campaign' => $selected_campaign]);
    $campaign_statistics = $statement->fetch(PDO::FETCH_ASSOC);

    return $campaign_statistics;
}

function get_campaigns($connect)
{
    $query = "SELECT DISTINCT campaign_name FROM email_data ORDER BY campaign_name";
    $statement = $connect->query($query);
    $campaigns = $statement->fetchAll(PDO::FETCH_COLUMN);
    return $campaigns;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }
        .container {
            padding-top: 50px;
            
        }
        h2 {
            margin-bottom: 30px;
            text-align: center;
        }
        .campaign-name {
            font-size: 20px;
            font-weight: bold;
            text-align: center;
            margin-bottom: 30px;
        }
        .email-count {
            padding: 10px;
            margin-bottom: 20px;
            background-color: #fff;
            border: 2px solid black;
            border-radius: 10px;
            text-align: center;
        }
        .chart-container {
            margin: auto;
            width: 100%;
            max-width: 400px;
            height: 300px;
            background-color:white;
            border-radius: 25px solid black ;
        }
        .container {
            max-width: 1300px;
            margin: 60px auto;
            padding: 30px;
            background-color:white;
            border-radius: 30px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
          
        }
        .btn-back {
            margin-top: 20px;
            text-align: center;
        }
        .page-container {
            border: 2px solid black; 
            border-radius: 20px;
            padding: 40px;
            margin: 30px auto; 
            max-width: 1000px;
            
        }
        .logo-container {
            text-align: center;
            margin-bottom: 20px;
        }
        .logo-container img {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            box-shadow: white;
        }
    
        @media (max-width: 768px) {
             .chart-container {
                max-width: 100%;
                height: auto;
            }
        }      
    </style>
</head>
<body>
    <div class="page-container">
        <div class="container mt-5">
            <div class="logo-container">
                <img src="http://localhost/track_email_22/IA1.jpg" >
            </div>
            <h2 class="text-center mb-4"><b>Overview<b></h2>
            <form id="emailForm" action="" method="post" class="form-inline justify-content-center">
                <div class="form-group">
                    <select class="form-control" name="campaign" onchange="this.form.submit()">
                        <option value="">Select Campaign</option>
                        <?php
                        $campaigns = get_campaigns($connect);
                        foreach ($campaigns as $campaign) {
                            echo "<option value='$campaign'>$campaign</option>";
                        }
                        ?>
                    </select>
                </div>
            </form>
            <?php if (isset($_POST['campaign']) || empty($_POST['campaign'])) : ?>
                <?php
                $selected_campaign = $_POST['campaign'] ?? ''; 
                $campaign_statistics = fetch_campaign_statistics($connect, $selected_campaign);
                ?>
                <div class="campaign-name"><?php echo $campaign_statistics['campaign_name'] ?? 'No Campaign Selected'; ?></div>
                <div class="row justify-content-center">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <div class="email-count">
                                    <p class="font-weight-bold">Opened Emails</p>
                                    <p><?php echo $campaign_statistics['opened_emails'] ?? 0; ?> (<?php echo round(($campaign_statistics['opened_emails'] ?? 0) / ($campaign_statistics['total_emails'] ?? 1) * 100, 2); ?>%)</p>
                                </div>
                                <div class="email-count">
                                    <p class="font-weight-bold">Not Opened Emails</p>
                                    <p><?php echo $campaign_statistics['not_opened_emails'] ?? 0; ?> (<?php echo round(($campaign_statistics['not_opened_emails'] ?? 0) / ($campaign_statistics['total_emails'] ?? 1) * 100, 2); ?>%)</p>
                                </div>
                                <div class="email-count">
                                    <p class="font-weight-bold">Bounced Emails</p>
                                    <p><?php echo $campaign_statistics['bounced_emails'] ?? 0; ?> (<?php echo round(($campaign_statistics['bounced_emails'] ?? 0) / ($campaign_statistics['total_emails'] ?? 1) * 100, 2); ?>%)</p>
                                </div>
                                <div class="email-count">
                                    <p class="font-weight-bold">Total Emails</p>
                                    <p><?php echo $campaign_statistics['total_emails'] ?? 0; ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                           <div class="chart-container">
                            <canvas id="campaignChart"></canvas>
                </div>
                    </div>
                
                         </div>
                </div>
            <?php endif; ?>
            <div class="btn-back">
                <button class="btn btn-primary" onclick="goBack()">Back</button>
            </div>
        </div>
    </div>

    <script>
        <?php
        if (isset($_POST['campaign'])) {
            $selected_campaign = $_POST['campaign'];
            $campaign_statistics = fetch_campaign_statistics($connect, $selected_campaign);
        } else {
            $campaign_statistics = fetch_campaign_statistics($connect, '');
        }
        ?>

        var ctx = document.getElementById('campaignChart').getContext('2d');

        var myChart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: ['Opened', 'Not Opened', 'Bounced', 'Total'],
                datasets: [{
                    label: 'Emails',
                    data: [
                        <?php echo $campaign_statistics['opened_emails'] ?? 0; ?>,
                        <?php echo $campaign_statistics['not_opened_emails'] ?? 0; ?>,
                        <?php echo $campaign_statistics['bounced_emails'] ?? 0; ?>,
                        <?php echo $campaign_statistics['total_emails'] ?? 0; ?>
                    ],
                    backgroundColor: [
                        'rgb(57, 28, 255)',
                        'rgba(255, 0, 0, 0.8)',
                        'rgba(255, 165, 0, 0.8)',
                        'rgba(75, 192, 192, 0.8)',
                    ],

                    borderColor: [
                        'rgba(54, 162, 235, 0.8)',
                        'rgba(255, 99, 132, 0.8)',
                        'rgba(255, 205, 86, 0.8)',
                        'rgba(75, 192, 192, 0.8)',
                   ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                legend: {
                    position: 'right'
                },
                tooltips: {
                    callbacks: {
                        label: function(tooltipItem, data) {
                            var dataset = data.datasets[tooltipItem.datasetIndex];
                            var total = dataset.data.reduce(function(previousValue, currentValue, currentIndex, array) {
                                return previousValue + currentValue;
                            });
                            var currentValue = dataset.data[tooltipItem.index];
                            var percentage = Math.floor(((currentValue / total) * 100) + 0.5);
                            return currentValue + " (" + percentage + "%)";
                        }
                    }
                }
            }
        });

        function goBack() {
            window.location.href = 'tracking_results.php';
        }
        
    </script>

    <footer>
        <div class="container" align="center">
            <p><b>&copy; 2024 Intent-Amplify Email Marketing. All rights reserved.<b></p>
        </div>
    </footer>
</body>
</html>

