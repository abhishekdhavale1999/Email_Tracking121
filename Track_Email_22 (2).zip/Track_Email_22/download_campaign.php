<?php

$connect = new PDO("mysql:host=localhost;dbname=testing", "root", "");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["download_campaign"]) && !empty($_POST["download_campaign"])) {
        $campaign = $_POST["download_campaign"];

        $query = "SELECT * FROM email_data WHERE campaign_name = :campaign_name";
        $statement = $connect->prepare($query);
        $statement->execute(['campaign_name' => $campaign]);
        $result = $statement->fetchAll(PDO::FETCH_ASSOC);

        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="'.$campaign.'_data.csv"');

        $output = fopen('php://output', 'w');

        fputcsv($output, array('Campaign Name', 'Email', 'Subject', 'Status', 'Open Datetime', 'Email Open Count', 'Time Spent', 'POC Click Time'));

        foreach ($result as $row) {
            $status = ($row['email_status'] == 'yes') ? 'Open' : 'Not Open';
            fputcsv($output, array($row['campaign_name'], $row['email_address'], $row['email_subject'], $status, $row['email_open_datetime'], $row['email_open_count'], $row['time_spent'], $row['Click_Time']));
        } 
        fclose($output);
        exit();
    } else {
        header("Location: tracking_results.php");
        exit();
    }
}
?>
