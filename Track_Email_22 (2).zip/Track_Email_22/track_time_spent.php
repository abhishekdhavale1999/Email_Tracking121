<?php

$connect = new PDO("mysql:host=localhost;dbname=testing", "root", "");

if (isset($_POST["code"])) {
    $imageLoadTime = date("Y-m-d H:i:s");
    
    $query = "
        UPDATE email_data 
        SET time_spent = TIMESTAMPDIFF(SECOND, email_open_datetime, :image_load_datetime)
        WHERE email_track_code = :code
    ";
    $statement = $connect->prepare($query);
    $statement->bindParam(':image_load_datetime', $imageLoadTime);
    $statement->bindParam(':code', $_POST["code"]);
    $statement->execute();
}
