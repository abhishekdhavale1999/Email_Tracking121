<?php

$connect = new PDO("mysql:host=localhost;dbname=testing", "root", "");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST["campaign"])) {
        $campaign_name = $_POST["campaign"];

        $query = "DELETE FROM email_data WHERE campaign_name = :campaign_name";
        $statement = $connect->prepare($query);
        $statement->execute(array(':campaign_name' => $campaign_name));

        header("Location: tracking_results.php");
        exit();
    } else {
        header("Location: tracking_results.php");
        exit();
    }
}
?>
